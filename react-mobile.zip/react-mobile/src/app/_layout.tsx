import { Slot } from 'expo-router';

export default function Layout() {
  // O Slot diz ao app: "Apenas mostre a tela atual, sem barras ou menus!"
  return <Slot />;
}