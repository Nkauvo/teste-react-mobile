import AsyncStorage from '@react-native-async-storage/async-storage';
import { useEffect, useState } from 'react';
import {
  FlatList,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View
} from 'react-native';

interface Tarefa {
  id: string;
  texto: string;
  concluida: boolean;
}

type FiltroTipo = 'todas' | 'pendentes' | 'concluidas';

export default function App() {
  const [tarefas, setTarefas] = useState<Tarefa[]>([]);
  const [novoTexto, setNovoTexto] = useState('');
  const [filtroAtivo, setFiltroAtivo] = useState<FiltroTipo>('todas');

  // Carregar dados ao iniciar
  useEffect(() => {
    carregarTarefas();
  }, []);

  // Salvar dados automaticamente
  useEffect(() => {
    salvarTarefas(tarefas);
  }, [tarefas]);

  const carregarTarefas = async () => {
    try {
      const dadosSalvos = await AsyncStorage.getItem('@todo_premium_tarefas');
      if (dadosSalvos !== null) setTarefas(JSON.parse(dadosSalvos));
    } catch (e) { console.log(e); }
  };

  const salvarTarefas = async (lista: Tarefa[]) => {
    try {
      await AsyncStorage.setItem('@todo_premium_tarefas', JSON.stringify(lista));
    } catch (e) { console.log(e); }
  };

  const adicionarTarefa = () => {
    if (novoTexto.trim() === '') return;
    
    const nova: Tarefa = {
      id: Date.now().toString(),
      texto: novoTexto.trim(),
      concluida: false
    };
    
    setTarefas([nova, ...tarefas]); // Coloca a mais recente no topo
    setNovoTexto('');
  };

  const alternarConcluir = (id: string) => {
    setTarefas(tarefas.map(t => t.id === id ? { ...t, concluida: !t.concluida } : t));
  };

  const deletarTarefa = (id: string) => {
    setTarefas(tarefas.filter(t => t.id !== id));
  };

  // --- Cálculos das Estatísticas ---
  const totalTarefas = tarefas.length;
  const totalConcluidas = tarefas.filter(t => t.concluida).length;
  const progresso = totalTarefas > 0 ? totalConcluidas / totalTarefas : 0;
  const porcentagemTexto = `${Math.round(progresso * 100)}%`;

  // --- Filtragem da Lista ---
  const tarefasFiltradas = tarefas.filter(t => {
    if (filtroAtivo === 'pendentes') return !t.concluida;
    if (filtroAtivo === 'concluidas') return t.concluida;
    return true; // 'todas'
  });

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" />
      
      {/* Cabeçalho */}
      <View style={styles.header}>
        <Text style={styles.tituloHeader}>FocusTask</Text>
        <Text style={styles.subtituloHeader}>Organize sua rotina com estilo</Text>
      </View>

      {/* Card de Progresso / Dashboard */}
      <View style={styles.cardProgresso}>
        <View style={styles.textoProgressoArea}>
          <Text style={styles.tituloProgresso}>Seu progresso</Text>
          <Text style={styles.numeroProgresso}>{totalConcluidas}/{totalTarefas}</Text>
        </View>
        {/* Barra de Progresso Background */}
        <View style={styles.barraProgressoBg}>
          {/* Barra preenchida dinamicamente */}
          <View style={[styles.barraProgressoPreenchida, { width: porcentagemTexto as any }]} />
        </View>
        <Text style={styles.textoPorcentagem}>{porcentagemTexto} concluído</Text>
      </View>

      {/* Input de Criação */}
      <View style={styles.containerInput}>
        <TextInput
          style={styles.input}
          placeholder="O que você vai fazer hoje?"
          placeholderTextColor="#6c757d"
          value={novoTexto}
          onChangeText={setNovoTexto}
          onSubmitEditing={adicionarTarefa} // Permite adicionar apertando Enter no teclado
        />
        <TouchableOpacity style={styles.botaoAdicionar} onPress={adicionarTarefa} activeOpacity={0.8}>
          <Text style={styles.textoBotaoAdicionar}>+</Text>
        </TouchableOpacity>
      </View>

      {/* Filtros (Tabs) */}
      <View style={styles.containerFiltros}>
        {(['todas', 'pendentes', 'concluidas'] as FiltroTipo[]).map((tipo) => (
          <TouchableOpacity
            key={tipo}
            style={[styles.botaoFiltro, filtroAtivo === tipo && styles.botaoFiltroAtivo]}
            onPress={() => setFiltroAtivo(tipo)}
          >
            <Text style={[styles.textoFiltro, filtroAtivo === tipo && styles.textoFiltroAtivo]}>
              {tipo.charAt(0).toUpperCase() + tipo.slice(1)}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Lista de Tarefas */}
      <FlatList
        data={tarefasFiltradas}
        keyExtractor={(item) => item.id}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 30 }}
        ListEmptyComponent={() => (
          <Text style={styles.listaVazia}>Nenhuma tarefa por aqui... 😴</Text>
        )}
        renderItem={({ item }) => (
          <View style={[styles.itemTarefa, item.concluida && styles.itemTarefaConcluido]}>
            <TouchableOpacity 
              style={styles.checkArea} 
              onPress={() => alternarConcluir(item.id)}
              activeOpacity={0.7}
            >
              <View style={[styles.checkbox, item.concluida && styles.checkboxMarcado]}>
                {item.concluida && <Text style={styles.checkSimbolo}>✓</Text>}
              </View>
              
              <Text style={[styles.textoTarefa, item.concluida && styles.textoTarefaConcluido]}>
                {item.texto}
              </Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.botaoDeletar} onPress={() => deletarTarefa(item.id)}>
              <Text style={styles.textoDeletar}>✕</Text>
            </TouchableOpacity>
          </View>
        )}
      />
    </View>
  );
}

// --- Estilos CSS Clean/Moderno ---
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0d0e12', // Dark bem profundo (estilo apps modernos)
    paddingTop: 50,
    paddingHorizontal: 24,
  },
  header: {
    marginBottom: 25,
  },
  tituloHeader: {
    fontSize: 32,
    fontWeight: '800',
    color: '#fff',
    letterSpacing: -0.5,
  },
  subtituloHeader: {
    fontSize: 14,
    color: '#6c757d',
    marginTop: 4,
  },
  cardProgresso: {
    backgroundColor: '#16181f',
    borderRadius: 16,
    padding: 20,
    marginBottom: 25,
    borderWidth: 1,
    borderColor: '#232632',
  },
  textoProgressoArea: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  tituloProgresso: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  numeroProgresso: {
    color: '#9d4edd', // Roxo neon discreto
    fontWeight: 'bold',
    fontSize: 14,
  },
  barraProgressoBg: {
    height: 8,
    backgroundColor: '#232632',
    borderRadius: 4,
    overflow: 'hidden',
    marginBottom: 10,
  },
  barraProgressoPreenchida: {
    height: '100%',
    backgroundColor: '#9d4edd', // Cor da barra de progresso
    borderRadius: 4,
  },
  textoPorcentagem: {
    color: '#6c757d',
    fontSize: 12,
  },
  containerInput: {
    flexDirection: 'row',
    marginBottom: 20,
  },
  input: {
    flex: 1,
    backgroundColor: '#16181f',
    color: '#fff',
    paddingHorizontal: 16,
    height: 54,
    borderRadius: 12,
    fontSize: 16,
    borderWidth: 1,
    borderColor: '#232632',
  },
  botaoAdicionar: {
    backgroundColor: '#9d4edd',
    justifyContent: 'center',
    alignItems: 'center',
    width: 54,
    height: 54,
    borderRadius: 12,
    marginLeft: 10,
  },
  textoBotaoAdicionar: {
    color: '#fff',
    fontSize: 26,
    fontWeight: '300',
  },
  containerFiltros: {
    flexDirection: 'row',
    backgroundColor: '#16181f',
    padding: 4,
    borderRadius: 10,
    marginBottom: 20,
  },
  botaoFiltro: {
    flex: 1,
    paddingVertical: 10,
    alignItems: 'center',
    borderRadius: 8,
  },
  botaoFiltroAtivo: {
    backgroundColor: '#232632',
  },
  textoFiltro: {
    color: '#6c757d',
    fontWeight: '600',
    fontSize: 13,
  },
  textoFiltroAtivo: {
    color: '#fff',
  },
  lista: {
    flex: 1,
  },
  itemTarefa: {
    backgroundColor: '#16181f',
    padding: 16,
    borderRadius: 14,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#232632',
  },
  itemTarefaConcluido: {
    opacity: 0.6,
  },
  checkArea: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  checkbox: {
    width: 22,
    height: 22,
    borderRadius: 6,
    borderWidth: 2,
    borderColor: '#495057',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 14,
  },
  checkboxMarcado: {
    backgroundColor: '#9d4edd',
    borderColor: '#9d4edd',
  },
  checkSimbolo: {
    color: '#fff',
    fontSize: 12,
    fontWeight: 'bold',
  },
  textoTarefa: {
    color: '#f8f9fa',
    fontSize: 15,
    fontWeight: '500',
    flex: 1,
  },
  textoTarefaConcluido: {
    color: '#6c757d',
    textDecorationLine: 'line-through',
  },
  botaoDeletar: {
    paddingLeft: 10,
  },
  textoDeletar: {
    color: '#e63946',
    fontSize: 16,
    fontWeight: 'bold',
  },
  listaVazia: {
    color: '#495057',
    textAlign: 'center',
    marginTop: 40,
    fontSize: 15,
  },
});